from escape_game_lw.main import init_game

from escape_game_lw.main import check_info

from escape_game_lw.main import pin_codes 
from escape_game_lw.main import check_way_to_office

from escape_game_lw.main import check_login_computer
from escape_game_lw.main import get_login_times
from escape_game_lw.main import get_browser_history
from escape_game_lw.main import check_website_name
from escape_game_lw.main import get_website_text
from escape_game_lw.main import check_telephone_numer
    
from escape_game_lw.main import check_coordinates_text
from escape_game_lw.main import check_distance
from escape_game_lw.main import check_location_message

from escape_game_lw.main import open_emergency_text
from escape_game_lw.main import check_find_prototyp

from escape_game_lw.main import get_map
from escape_game_lw.main import check_strongest_signal

from escape_game_lw.main import get_list_devices
from escape_game_lw.main import try_add_device
from escape_game_lw.main import check_device_added
