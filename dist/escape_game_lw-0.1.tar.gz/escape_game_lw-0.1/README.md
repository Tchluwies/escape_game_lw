# escape_game_lw

This are the functions for an experimental escape game exercise.